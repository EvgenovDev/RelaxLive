<?php 
sleep (1);
echo $_SERVER[‘REMOTE_ADDR‘];